export interface Education {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  isCurrentlyStudying?: boolean;
  description?: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  location?: string;
  isRemote?: boolean;
  startDate: string;
  endDate: string;
  isCurrentlyWorking?: boolean;
  description: string;
}

export interface Language {
  id: string;
  name: string;
  proficiency: 'Basic' | 'Intermediate' | 'Advanced' | 'Fluent' | 'Native';
}

export interface Certificate {
  id: string;
  name: string;
  issuingOrganization: string;
  issueDate: string;
  expirationDate?: string;
  credentialId?: string;
  credentialUrl?: string;
}

export interface Resume {
  id: string;
  title?: string;
  fullName: string;
  email: string;
  phone: string;
  location?: string;
  professionalSummary?: string;
  skills: string[];
  education: Education[];
  experience: Experience[];
  languages: Language[];
  certificates: Certificate[];
  createdAt: string;
  updatedAt: string;
}