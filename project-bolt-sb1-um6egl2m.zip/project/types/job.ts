export interface Job {
  id: string;
  title: string;
  companyName: string;
  location: string;
  type: string; // Full-time, Part-time, Contract, etc.
  schedule: string; // Flexible, 9-5, etc.
  salary?: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  tags: string[];
  postedTime: string;
  postedDate: Date;
  isFeatured?: boolean;
  isRemote?: boolean;
  isInternational?: boolean;
}

export interface JobFilter {
  jobType?: string[];
  location?: string;
  remote?: boolean;
  salary?: {
    min?: number;
    max?: number;
  };
  experience?: string[];
  postedDate?: string;
}