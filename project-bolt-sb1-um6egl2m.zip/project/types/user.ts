export interface User {
  id: string;
  email: string;
  phone?: string;
  fullName: string;
  avatar?: string;
  role: 'jobseeker' | 'employer' | 'admin';
  location?: string;
  preferredLanguage?: 'en' | 'ru' | 'uz';
  savedJobs?: string[];
  appliedJobs?: string[];
  resumeIds?: string[];
  isVerified?: boolean;
  foreignJobsVerified?: boolean;
  createdAt: string;
  lastActive?: string;
}