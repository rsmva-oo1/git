import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { FileText, Calendar, Award } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Card from '@/components/ui/Card';
import { Resume } from '@/types/resume';

interface ResumeCardProps {
  resume: Resume;
}

export default function ResumeCard({ resume }: ResumeCardProps) {
  const router = useRouter();

  const handlePress = () => {
    router.push(`/(tabs)/resumes/${resume.id}`);
  };

  return (
    <Card>
      <TouchableOpacity onPress={handlePress} style={styles.container} activeOpacity={0.8}>
        <View style={styles.header}>
          <FileText size={24} color={Colors.primary[500]} />
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>{resume.title || 'My Resume'}</Text>
            <Text style={styles.updatedDate}>Updated {resume.updatedAt}</Text>
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Award size={16} color={Colors.neutral[600]} />
            <Text style={styles.sectionTitle}>Skills</Text>
          </View>
          <View style={styles.tags}>
            {resume.skills.slice(0, 5).map((skill, index) => (
              <View key={index} style={styles.tag}>
                <Text style={styles.tagText}>{skill}</Text>
              </View>
            ))}
            {resume.skills.length > 5 && (
              <View style={styles.tag}>
                <Text style={styles.tagText}>+{resume.skills.length - 5} more</Text>
              </View>
            )}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Calendar size={16} color={Colors.neutral[600]} />
            <Text style={styles.sectionTitle}>Experience</Text>
          </View>
          <Text style={styles.experienceText}>
            {resume.experience.length > 0
              ? `${resume.experience.length} experience entries`
              : 'No experience added yet'}
          </Text>
        </View>
        
        <View style={styles.footer}>
          <TouchableOpacity 
            style={styles.editButton} 
            onPress={() => router.push(`/(tabs)/resumes/edit/${resume.id}`)}
          >
            <Text style={styles.editButtonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.previewButton} onPress={handlePress}>
            <Text style={styles.previewButtonText}>Preview</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Theme.spacing.md,
  },
  headerTextContainer: {
    marginLeft: Theme.spacing.sm,
    flex: 1,
  },
  title: {
    fontSize: Theme.typography.fontSize.lg,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  updatedDate: {
    fontSize: Theme.typography.fontSize.xs,
    color: Colors.neutral[500],
    fontFamily: Theme.typography.fontFamily.regular,
  },
  section: {
    marginBottom: Theme.spacing.md,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Theme.spacing.xs,
  },
  sectionTitle: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[800],
    marginLeft: Theme.spacing.xs,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tag: {
    backgroundColor: Colors.secondary[50],
    paddingHorizontal: Theme.spacing.sm,
    paddingVertical: 2,
    borderRadius: Theme.borderRadius.full,
    marginRight: Theme.spacing.xs,
    marginBottom: Theme.spacing.xs,
  },
  tagText: {
    fontSize: Theme.typography.fontSize.xs,
    color: Colors.secondary[700],
    fontFamily: Theme.typography.fontFamily.medium,
  },
  experienceText: {
    fontSize: Theme.typography.fontSize.sm,
    color: Colors.neutral[700],
    fontFamily: Theme.typography.fontFamily.regular,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: Theme.spacing.sm,
  },
  editButton: {
    paddingHorizontal: Theme.spacing.md,
    paddingVertical: Theme.spacing.xs,
    borderRadius: Theme.borderRadius.sm,
    marginRight: Theme.spacing.sm,
  },
  editButtonText: {
    color: Colors.primary[500],
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.medium,
  },
  previewButton: {
    backgroundColor: Colors.primary[50],
    paddingHorizontal: Theme.spacing.md,
    paddingVertical: Theme.spacing.xs,
    borderRadius: Theme.borderRadius.sm,
  },
  previewButtonText: {
    color: Colors.primary[700],
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.medium,
  },
});