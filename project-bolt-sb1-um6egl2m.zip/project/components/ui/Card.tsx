import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';

interface CardProps extends ViewProps {
  variant?: 'elevated' | 'outlined' | 'filled';
  children: React.ReactNode;
}

export default function Card({ 
  variant = 'elevated', 
  children, 
  style, 
  ...props 
}: CardProps) {
  return (
    <View style={[styles.base, styles[variant], style]} {...props}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: Theme.borderRadius.md,
    padding: Theme.spacing.md,
    marginVertical: Theme.spacing.sm,
  },
  elevated: {
    backgroundColor: Colors.white,
    ...Theme.shadow.md,
  },
  outlined: {
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  filled: {
    backgroundColor: Colors.neutral[50],
  },
});