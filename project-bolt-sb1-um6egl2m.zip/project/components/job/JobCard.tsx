import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { MapPin, Briefcase, Clock, DollarSign } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { Job } from '@/types/job';

interface JobCardProps {
  job: Job;
  isSaved?: boolean;
  onSave?: () => void;
}

export default function JobCard({ job, isSaved = false, onSave }: JobCardProps) {
  const router = useRouter();

  const handlePress = () => {
    router.push(`/(tabs)/jobs/${job.id}`);
  };

  return (
    <Card>
      <TouchableOpacity onPress={handlePress} style={styles.container} activeOpacity={0.8}>
        <View style={styles.header}>
          <Text style={styles.companyName}>{job.companyName}</Text>
          <Text style={styles.postedTime}>{job.postedTime}</Text>
        </View>
        
        <Text style={styles.title}>{job.title}</Text>
        
        <View style={styles.infoContainer}>
          <View style={styles.infoItem}>
            <MapPin size={16} color={Colors.neutral[500]} />
            <Text style={styles.infoText}>{job.location}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Briefcase size={16} color={Colors.neutral[500]} />
            <Text style={styles.infoText}>{job.type}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Clock size={16} color={Colors.neutral[500]} />
            <Text style={styles.infoText}>{job.schedule}</Text>
          </View>
          
          {job.salary && (
            <View style={styles.infoItem}>
              <DollarSign size={16} color={Colors.neutral[500]} />
              <Text style={styles.infoText}>{job.salary}</Text>
            </View>
          )}
        </View>
        
        <View style={styles.tags}>
          {job.tags.map((tag, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
        
        <View style={styles.footer}>
          <Button 
            title="Apply Now" 
            onPress={handlePress} 
            variant="primary"
            size="sm"
          />
          <Button 
            title={isSaved ? "Saved" : "Save"} 
            onPress={onSave} 
            variant={isSaved ? "ghost" : "outline"} 
            size="sm"
          />
        </View>
      </TouchableOpacity>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.xs,
  },
  companyName: {
    fontSize: Theme.typography.fontSize.sm,
    color: Colors.primary[500],
    fontFamily: Theme.typography.fontFamily.medium,
  },
  postedTime: {
    fontSize: Theme.typography.fontSize.sm,
    color: Colors.neutral[500],
    fontFamily: Theme.typography.fontFamily.regular,
  },
  title: {
    fontSize: Theme.typography.fontSize.lg,
    fontFamily: Theme.typography.fontFamily.bold,
    marginBottom: Theme.spacing.sm,
    color: Colors.neutral[900],
  },
  infoContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: Theme.spacing.sm,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: Theme.spacing.md,
    marginBottom: Theme.spacing.xs,
  },
  infoText: {
    fontSize: Theme.typography.fontSize.sm,
    color: Colors.neutral[700],
    marginLeft: 4,
    fontFamily: Theme.typography.fontFamily.regular,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: Theme.spacing.md,
  },
  tag: {
    backgroundColor: Colors.primary[50],
    paddingHorizontal: Theme.spacing.sm,
    paddingVertical: 2,
    borderRadius: Theme.borderRadius.full,
    marginRight: Theme.spacing.xs,
    marginBottom: Theme.spacing.xs,
  },
  tagText: {
    fontSize: Theme.typography.fontSize.xs,
    color: Colors.primary[700],
    fontFamily: Theme.typography.fontFamily.medium,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});