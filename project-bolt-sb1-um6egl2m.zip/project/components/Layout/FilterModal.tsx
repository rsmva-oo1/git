import React, { useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  Modal, 
  TouchableOpacity, 
  ScrollView,
  SafeAreaView,
  Platform
} from 'react-native';
import { X } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Button from '@/components/ui/Button';

interface FilterOption {
  id: string;
  label: string;
}

interface FilterSection {
  id: string;
  title: string;
  options: FilterOption[];
  multiSelect?: boolean;
}

interface FilterModalProps {
  visible: boolean;
  onClose: () => void;
  onApply: (filters: Record<string, string | string[]>) => void;
  filters: FilterSection[];
  initialValues?: Record<string, string | string[]>;
}

export default function FilterModal({
  visible,
  onClose,
  onApply,
  filters,
  initialValues = {}
}: FilterModalProps) {
  const [selectedFilters, setSelectedFilters] = useState<Record<string, string | string[]>>(initialValues);

  const handleSelectOption = (sectionId: string, optionId: string, multiSelect?: boolean) => {
    setSelectedFilters(prev => {
      const current = prev[sectionId];
      
      if (multiSelect) {
        // Handle multi-select case
        const currentArray = Array.isArray(current) ? current : [];
        if (currentArray.includes(optionId)) {
          return {
            ...prev,
            [sectionId]: currentArray.filter(id => id !== optionId)
          };
        } else {
          return {
            ...prev,
            [sectionId]: [...currentArray, optionId]
          };
        }
      } else {
        // Handle single-select case
        if (current === optionId) {
          const { [sectionId]: _, ...rest } = prev;
          return rest;
        } else {
          return {
            ...prev,
            [sectionId]: optionId
          };
        }
      }
    });
  };

  const isOptionSelected = (sectionId: string, optionId: string) => {
    const selected = selectedFilters[sectionId];
    if (Array.isArray(selected)) {
      return selected.includes(optionId);
    }
    return selected === optionId;
  };

  const handleReset = () => {
    setSelectedFilters({});
  };

  const handleApply = () => {
    onApply(selectedFilters);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Filters</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color={Colors.neutral[700]} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.filtersContainer}>
            {filters.map(section => (
              <View key={section.id} style={styles.section}>
                <Text style={styles.sectionTitle}>{section.title}</Text>
                <View style={styles.optionsContainer}>
                  {section.options.map(option => (
                    <TouchableOpacity
                      key={option.id}
                      style={[
                        styles.optionButton,
                        isOptionSelected(section.id, option.id) && styles.selectedOption
                      ]}
                      onPress={() => handleSelectOption(section.id, option.id, section.multiSelect)}
                    >
                      <Text 
                        style={[
                          styles.optionText,
                          isOptionSelected(section.id, option.id) && styles.selectedOptionText
                        ]}
                      >
                        {option.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            ))}
          </ScrollView>
          
          <View style={styles.footer}>
            <Button
              title="Reset"
              onPress={handleReset}
              variant="outline"
              style={styles.resetButton}
            />
            <Button
              title="Apply Filters"
              onPress={handleApply}
              style={styles.applyButton}
            />
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: Platform.OS === 'web' ? 'rgba(0, 0, 0, 0.5)' : 'transparent',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: Theme.borderRadius.lg,
    borderTopRightRadius: Theme.borderRadius.lg,
    ...Platform.select({
      web: {
        width: '100%',
        maxWidth: 600,
        maxHeight: '90%',
        alignSelf: 'center',
        borderRadius: Theme.borderRadius.lg,
        ...Theme.shadow.lg,
      },
      default: {
        height: '80%',
      }
    }),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  title: {
    fontSize: Theme.typography.fontSize.xl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  closeButton: {
    padding: Theme.spacing.xs,
  },
  filtersContainer: {
    flex: 1,
  },
  section: {
    padding: Theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  sectionTitle: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[800],
    marginBottom: Theme.spacing.sm,
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  optionButton: {
    backgroundColor: Colors.neutral[100],
    paddingHorizontal: Theme.spacing.md,
    paddingVertical: Theme.spacing.xs,
    borderRadius: Theme.borderRadius.full,
    marginRight: Theme.spacing.sm,
    marginBottom: Theme.spacing.sm,
  },
  selectedOption: {
    backgroundColor: Colors.primary[500],
  },
  optionText: {
    fontSize: Theme.typography.fontSize.sm,
    color: Colors.neutral[700],
    fontFamily: Theme.typography.fontFamily.medium,
  },
  selectedOptionText: {
    color: Colors.white,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: Theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[200],
  },
  resetButton: {
    flex: 1,
    marginRight: Theme.spacing.sm,
  },
  applyButton: {
    flex: 2,
  },
});