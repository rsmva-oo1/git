import en from './en';
import ru from './ru';
import uz from './uz';

export { en, ru, uz };