import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Image, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Globe } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import i18n from '@/utils/i18n';

export default function LoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }

    setLoading(true);
    setError('');
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      // For demo purposes, navigate to main app
      router.replace('/(tabs)');
    }, 1500);
  };

  const handleLanguageChange = () => {
    // In a real app, show a language picker and update using changeLanguage from i18n.ts
    const languages = ['en', 'ru', 'uz'];
    const currentIndex = languages.indexOf(i18n.locale);
    const nextIndex = (currentIndex + 1) % languages.length;
    
    i18n.locale = languages[nextIndex];
    // Force re-render
    setLoading(prevLoading => prevLoading);
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <TouchableOpacity 
          style={styles.languageButton} 
          onPress={handleLanguageChange}
        >
          <Globe size={20} color={Colors.primary[500]} />
          <Text style={styles.languageText}>{i18n.locale.toUpperCase()}</Text>
        </TouchableOpacity>

        <View style={styles.headerContainer}>
          <Text style={styles.title}>{i18n.t('common.appName')}</Text>
          <Text style={styles.subtitle}>{i18n.t('auth.login')}</Text>
        </View>
        
        <View style={styles.formContainer}>
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          
          <Input
            label={i18n.t('auth.email')}
            placeholder="example@email.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            required
          />
          
          <Input
            label={i18n.t('auth.password')}
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            required
          />
          
          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={styles.forgotPasswordText}>{i18n.t('auth.forgotPassword')}</Text>
          </TouchableOpacity>
          
          <Button
            title={i18n.t('auth.login')}
            onPress={handleLogin}
            loading={loading}
            fullWidth
            style={styles.loginButton}
          />
          
          <View style={styles.signupContainer}>
            <Text style={styles.signupText}>{i18n.t('auth.noAccount')}</Text>
            <Link href="/register" asChild>
              <TouchableOpacity>
                <Text style={styles.signupLink}>{i18n.t('auth.signup')}</Text>
              </TouchableOpacity>
            </Link>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: Theme.spacing.lg,
    justifyContent: 'center',
  },
  languageButton: {
    position: 'absolute',
    top: Theme.spacing.xl,
    right: Theme.spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    padding: Theme.spacing.sm,
    borderRadius: Theme.borderRadius.full,
    backgroundColor: Colors.primary[50],
  },
  languageText: {
    marginLeft: Theme.spacing.xs,
    color: Colors.primary[700],
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
  },
  headerContainer: {
    alignItems: 'center',
    marginBottom: Theme.spacing.xxl,
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: Theme.spacing.md,
  },
  title: {
    fontSize: 36,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.primary[500],
    marginBottom: Theme.spacing.xs,
  },
  subtitle: {
    fontSize: Theme.typography.fontSize.xl,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[700],
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  errorText: {
    color: Colors.error[500],
    marginBottom: Theme.spacing.md,
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: Theme.spacing.xl,
  },
  forgotPasswordText: {
    color: Colors.primary[500],
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
  },
  loginButton: {
    marginBottom: Theme.spacing.xl,
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signupText: {
    color: Colors.neutral[600],
    fontFamily: Theme.typography.fontFamily.regular,
    fontSize: Theme.typography.fontSize.sm,
  },
  signupLink: {
    color: Colors.primary[500],
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
    marginLeft: Theme.spacing.xs,
  },
});