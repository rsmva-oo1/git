import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { ArrowLeft, Globe } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import i18n from '@/utils/i18n';

export default function RegisterScreen() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<'jobseeker' | 'employer'>('jobseeker');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRegister = async () => {
    if (!fullName || !email || !password || !confirmPassword) {
      setError('Please fill all required fields');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError('');
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      // For demo purposes, navigate to main app
      router.replace('/(tabs)');
    }, 1500);
  };

  const handleLanguageChange = () => {
    // In a real app, show a language picker and update using changeLanguage from i18n.ts
    const languages = ['en', 'ru', 'uz'];
    const currentIndex = languages.indexOf(i18n.locale);
    const nextIndex = (currentIndex + 1) % languages.length;
    
    i18n.locale = languages[nextIndex];
    // Force re-render
    setLoading(prevLoading => prevLoading);
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton} 
            onPress={() => router.back()}
          >
            <ArrowLeft size={20} color={Colors.neutral[800]} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.languageButton} 
            onPress={handleLanguageChange}
          >
            <Globe size={20} color={Colors.primary[500]} />
            <Text style={styles.languageText}>{i18n.locale.toUpperCase()}</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.headerContainer}>
          <Text style={styles.title}>{i18n.t('auth.signup')}</Text>
          <Text style={styles.subtitle}>{i18n.t('auth.createAccount')}</Text>
        </View>
        
        <View style={styles.formContainer}>
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          
          <Input
            label={i18n.t('profile.personalInfo')}
            placeholder="Full Name"
            value={fullName}
            onChangeText={setFullName}
            autoCapitalize="words"
            required
          />
          
          <Input
            label={i18n.t('auth.email')}
            placeholder="example@email.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            required
          />
          
          <Input
            label={i18n.t('auth.phone')}
            placeholder="+998 XX XXX XX XX"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
          />
          
          <Input
            label={i18n.t('auth.password')}
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            required
          />
          
          <Input
            label="Confirm Password"
            placeholder="••••••••"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
            required
          />
          
          <View style={styles.roleSelector}>
            <Text style={styles.roleSelectorLabel}>I am a:</Text>
            <View style={styles.roleButtonsContainer}>
              <TouchableOpacity
                style={[
                  styles.roleButton,
                  role === 'jobseeker' && styles.roleButtonActive
                ]}
                onPress={() => setRole('jobseeker')}
              >
                <Text style={[
                  styles.roleButtonText,
                  role === 'jobseeker' && styles.roleButtonTextActive
                ]}>Job Seeker</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.roleButton,
                  role === 'employer' && styles.roleButtonActive
                ]}
                onPress={() => setRole('employer')}
              >
                <Text style={[
                  styles.roleButtonText,
                  role === 'employer' && styles.roleButtonTextActive
                ]}>Employer</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <Button
            title={i18n.t('auth.signup')}
            onPress={handleRegister}
            loading={loading}
            fullWidth
            style={styles.registerButton}
          />
          
          <View style={styles.loginContainer}>
            <Text style={styles.loginText}>{i18n.t('auth.hasAccount')}</Text>
            <Link href="/login" asChild>
              <TouchableOpacity>
                <Text style={styles.loginLink}>{i18n.t('auth.login')}</Text>
              </TouchableOpacity>
            </Link>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: Theme.spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.lg,
  },
  backButton: {
    padding: Theme.spacing.xs,
  },
  languageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Theme.spacing.sm,
    borderRadius: Theme.borderRadius.full,
    backgroundColor: Colors.primary[50],
  },
  languageText: {
    marginLeft: Theme.spacing.xs,
    color: Colors.primary[700],
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
  },
  headerContainer: {
    marginBottom: Theme.spacing.xl,
  },
  title: {
    fontSize: Theme.typography.fontSize.xxxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.xs,
  },
  subtitle: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[600],
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  errorText: {
    color: Colors.error[500],
    marginBottom: Theme.spacing.md,
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
  },
  roleSelector: {
    marginBottom: Theme.spacing.lg,
  },
  roleSelectorLabel: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[700],
    marginBottom: Theme.spacing.xs,
  },
  roleButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  roleButton: {
    flex: 1,
    paddingVertical: Theme.spacing.sm,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.neutral[300],
    backgroundColor: Colors.white,
    marginHorizontal: Theme.spacing.xs,
    borderRadius: Theme.borderRadius.md,
  },
  roleButtonActive: {
    backgroundColor: Colors.primary[500],
    borderColor: Colors.primary[500],
  },
  roleButtonText: {
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[700],
  },
  roleButtonTextActive: {
    color: Colors.white,
  },
  registerButton: {
    marginTop: Theme.spacing.md,
    marginBottom: Theme.spacing.lg,
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Theme.spacing.xl,
  },
  loginText: {
    color: Colors.neutral[600],
    fontFamily: Theme.typography.fontFamily.regular,
    fontSize: Theme.typography.fontSize.sm,
  },
  loginLink: {
    color: Colors.primary[500],
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
    marginLeft: Theme.spacing.xs,
  },
});