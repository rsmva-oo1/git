import React from 'react';
import { Tabs } from 'expo-router';
import { StyleSheet, View, Platform } from 'react-native';
import { Briefcase, FileText, Globe, User, MessageSquare } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import i18n from '@/utils/i18n';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors.primary[500],
        tabBarInactiveTintColor: Colors.neutral[400],
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarItemStyle: styles.tabBarItem,
        tabBarStyle: styles.tabBar,
        tabBarIconStyle: styles.tabBarIcon,
        headerShown: false,
      }}
    >
      <Tabs.Screen
        name="jobs"
        options={{
          title: i18n.t('tabs.jobs'),
          tabBarIcon: ({ color, size }) => (
            <View style={styles.iconContainer}>
              <Briefcase size={size-2} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="resumes"
        options={{
          title: i18n.t('tabs.resumes'),
          tabBarIcon: ({ color, size }) => (
            <View style={styles.iconContainer}>
              <FileText size={size-2} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="foreign"
        options={{
          title: i18n.t('tabs.foreign'),
          tabBarIcon: ({ color, size }) => (
            <View style={styles.iconContainer}>
              <Globe size={size-2} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="chat"
        options={{
          title: i18n.t('tabs.chat'),
          tabBarIcon: ({ color, size }) => (
            <View style={styles.iconContainer}>
              <MessageSquare size={size-2} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: i18n.t('tabs.profile'),
          tabBarIcon: ({ color, size }) => (
            <View style={styles.iconContainer}>
              <User size={size-2} color={color} />
            </View>
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    ...Platform.select({
      ios: {
        shadowColor: Colors.black,
        shadowOffset: { width: 0, height: -2 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
      },
      android: {
        elevation: 8,
      },
      web: {
        boxShadow: '0px -2px 10px rgba(0, 0, 0, 0.05)',
      },
    }),
    height: Platform.OS === 'ios' ? 90 : 70,
    paddingTop: 12,
    paddingBottom: Platform.OS === 'ios' ? 30 : 12,
  },
  tabBarLabel: {
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: 12,
    marginTop: 4,
  },
  tabBarItem: {
    paddingTop: 4,
  },
  tabBarIcon: {
    marginBottom: 0,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});