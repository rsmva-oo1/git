import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Plus } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import ResumeCard from '@/components/resume/ResumeCard';
import i18n from '@/utils/i18n';
import { Resume } from '@/types/resume';

// Mock data
const mockResumes: Resume[] = [
  {
    id: '1',
    title: 'Software Developer Resume',
    fullName: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+998 90 123 45 67',
    location: 'Tashkent, Uzbekistan',
    professionalSummary: 'Experienced software developer with expertise in React, JavaScript, and Node.js.',
    skills: ['React', 'JavaScript', 'TypeScript', 'Node.js', 'HTML', 'CSS', 'Git', 'SQL', 'MongoDB'],
    education: [
      {
        id: '1',
        institution: 'Tashkent University of Information Technologies',
        degree: 'Bachelor',
        fieldOfStudy: 'Computer Science',
        startDate: '2018',
        endDate: '2022',
      }
    ],
    experience: [
      {
        id: '1',
        company: 'Tech Solutions LLC',
        position: 'Frontend Developer',
        location: 'Tashkent',
        startDate: 'Jan 2022',
        endDate: 'Present',
        isCurrentlyWorking: true,
        description: 'Developed and maintained web applications using React and TypeScript.',
      }
    ],
    languages: [
      {
        id: '1',
        name: 'English',
        proficiency: 'Advanced',
      },
      {
        id: '2',
        name: 'Russian',
        proficiency: 'Fluent',
      },
      {
        id: '3',
        name: 'Uzbek',
        proficiency: 'Native',
      }
    ],
    certificates: [
      {
        id: '1',
        name: 'React Developer Certification',
        issuingOrganization: 'Meta',
        issueDate: 'March 2023',
      }
    ],
    createdAt: '2023-05-15',
    updatedAt: '2 weeks ago',
  },
  {
    id: '2',
    title: 'Graphic Designer Resume',
    fullName: 'Jane Smith',
    email: 'jane.smith@example.com',
    phone: '+998 90 987 65 43',
    professionalSummary: 'Creative graphic designer with experience in branding and digital design.',
    skills: ['Adobe Photoshop', 'Adobe Illustrator', 'Figma', 'UI/UX Design', 'Branding', 'Typography'],
    education: [
      {
        id: '1',
        institution: 'National Institute of Arts and Design',
        degree: 'Bachelor',
        fieldOfStudy: 'Graphic Design',
        startDate: '2019',
        endDate: '2023',
      }
    ],
    experience: [],
    languages: [
      {
        id: '1',
        name: 'English',
        proficiency: 'Intermediate',
      },
      {
        id: '2',
        name: 'Uzbek',
        proficiency: 'Native',
      }
    ],
    certificates: [],
    createdAt: '2023-08-20',
    updatedAt: '1 month ago',
  }
];

export default function ResumesScreen() {
  const router = useRouter();

  const handleCreateResume = () => {
    // Navigate to resume creation screen
    console.log('Create new resume');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{i18n.t('resumes.title')}</Text>
        <TouchableOpacity 
          style={styles.createButton}
          onPress={handleCreateResume}
        >
          <Plus size={20} color={Colors.white} />
          <Text style={styles.createButtonText}>{i18n.t('resumes.createResume')}</Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={mockResumes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ResumeCard resume={item} />
        )}
        contentContainerStyle={styles.resumesList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No resumes yet</Text>
            <TouchableOpacity 
              style={styles.emptyCreateButton}
              onPress={handleCreateResume}
            >
              <Text style={styles.emptyCreateButtonText}>Create your first resume</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Theme.spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    ...Theme.shadow.sm,
  },
  title: {
    fontSize: Theme.typography.fontSize.xxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  createButton: {
    backgroundColor: Colors.primary[500],
    borderRadius: Theme.borderRadius.md,
    paddingHorizontal: Theme.spacing.md,
    paddingVertical: Theme.spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
  },
  createButtonText: {
    color: Colors.white,
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.sm,
    marginLeft: Theme.spacing.xs,
  },
  resumesList: {
    padding: Theme.spacing.md,
  },
  emptyContainer: {
    padding: Theme.spacing.xxl,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.md,
    color: Colors.neutral[500],
    marginBottom: Theme.spacing.md,
  },
  emptyCreateButton: {
    backgroundColor: Colors.primary[500],
    borderRadius: Theme.borderRadius.md,
    paddingHorizontal: Theme.spacing.lg,
    paddingVertical: Theme.spacing.md,
  },
  emptyCreateButtonText: {
    color: Colors.white,
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.md,
  },
});