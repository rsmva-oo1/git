import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Switch, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
  User, 
  Settings, 
  Bell, 
  Globe, 
  Moon, 
  HelpCircle, 
  Info, 
  FileText, 
  Lock, 
  LogOut 
} from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import i18n from '@/utils/i18n';

export default function ProfileScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  
  const handleLanguageChange = () => {
    // In a real app, show a language picker
    const languages = ['en', 'ru', 'uz'];
    const currentIndex = languages.indexOf(i18n.locale);
    const nextIndex = (currentIndex + 1) % languages.length;
    
    i18n.locale = languages[nextIndex];
    
    // Force re-render
    setDarkMode(prevMode => prevMode);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{i18n.t('profile.title')}</Text>
      </View>
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>JS</Text>
            </View>
            <TouchableOpacity style={styles.editAvatarButton}>
              <Text style={styles.editAvatarText}>Change</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>John Smith</Text>
            <Text style={styles.profileEmail}>john.smith@example.com</Text>
            <TouchableOpacity style={styles.editProfileButton}>
              <Text style={styles.editProfileText}>{i18n.t('profile.editProfile')}</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          
          <TouchableOpacity style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <User size={20} color={Colors.primary[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.personalInfo')}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <FileText size={20} color={Colors.secondary[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.preferences')}</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>
          
          <View style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Bell size={20} color={Colors.accent[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.notifications')}</Text>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: Colors.neutral[300], true: Colors.primary[400] }}
              thumbColor={notifications ? Colors.primary[500] : Colors.white}
            />
          </View>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={handleLanguageChange}
          >
            <View style={styles.menuIconContainer}>
              <Globe size={20} color={Colors.success[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.language')}</Text>
            <Text style={styles.menuValueText}>{i18n.locale.toUpperCase()}</Text>
          </TouchableOpacity>
          
          <View style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Moon size={20} color={Colors.neutral[700]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.theme')}</Text>
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              trackColor={{ false: Colors.neutral[300], true: Colors.primary[400] }}
              thumbColor={darkMode ? Colors.primary[500] : Colors.white}
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          
          <TouchableOpacity style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <HelpCircle size={20} color={Colors.warning[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.help')}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Info size={20} color={Colors.info[500]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.about')}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Lock size={20} color={Colors.neutral[600]} />
            </View>
            <Text style={styles.menuText}>{i18n.t('profile.privacy')}</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity style={styles.logoutButton}>
          <LogOut size={20} color={Colors.error[500]} />
          <Text style={styles.logoutText}>{i18n.t('auth.logout')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Theme.spacing.lg,
    ...Theme.shadow.sm,
  },
  title: {
    fontSize: Theme.typography.fontSize.xxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Theme.spacing.md,
  },
  profileSection: {
    backgroundColor: Colors.white,
    borderRadius: Theme.borderRadius.lg,
    padding: Theme.spacing.lg,
    marginBottom: Theme.spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    ...Theme.shadow.sm,
  },
  avatarContainer: {
    alignItems: 'center',
    marginRight: Theme.spacing.lg,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Theme.spacing.xs,
  },
  avatarText: {
    fontSize: 32,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.primary[700],
  },
  editAvatarButton: {
    paddingVertical: Theme.spacing.xs,
  },
  editAvatarText: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.primary[500],
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: Theme.typography.fontSize.xl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.sm,
  },
  editProfileButton: {
    backgroundColor: Colors.primary[50],
    paddingVertical: Theme.spacing.xs,
    paddingHorizontal: Theme.spacing.md,
    borderRadius: Theme.borderRadius.md,
    alignSelf: 'flex-start',
  },
  editProfileText: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.primary[700],
  },
  section: {
    backgroundColor: Colors.white,
    borderRadius: Theme.borderRadius.lg,
    padding: Theme.spacing.md,
    marginBottom: Theme.spacing.lg,
    ...Theme.shadow.sm,
  },
  sectionTitle: {
    fontSize: Theme.typography.fontSize.lg,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[800],
    marginBottom: Theme.spacing.sm,
    paddingHorizontal: Theme.spacing.xs,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  menuIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.neutral[50],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Theme.spacing.md,
  },
  menuText: {
    flex: 1,
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[800],
  },
  menuValueText: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.primary[500],
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.error[50],
    padding: Theme.spacing.md,
    borderRadius: Theme.borderRadius.lg,
    marginBottom: Theme.spacing.xl,
  },
  logoutText: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.error[700],
    marginLeft: Theme.spacing.sm,
  },
});