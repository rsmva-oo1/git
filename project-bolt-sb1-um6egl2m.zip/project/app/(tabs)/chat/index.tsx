import React, { useState } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, TextInput, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Search, Send } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import i18n from '@/utils/i18n';

interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  receiverId: string;
  timestamp: string;
  isRead: boolean;
}

interface ChatThread {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar?: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
  isOnline?: boolean;
}

// Mock data
const mockChatThreads: ChatThread[] = [
  {
    id: '1',
    participantId: '101',
    participantName: 'TechCorp Recruiter',
    lastMessage: 'We would like to invite you for an interview tomorrow at 2pm.',
    timestamp: '10:30 AM',
    unreadCount: 2,
    isOnline: true,
  },
  {
    id: '2',
    participantId: '102',
    participantName: 'Creative Solutions HR',
    lastMessage: 'Your application has been received. We\'ll review it soon.',
    timestamp: 'Yesterday',
    unreadCount: 0,
    isOnline: false,
  },
  {
    id: '3',
    participantId: '103',
    participantName: 'Media Group',
    lastMessage: 'Thank you for your interest in our position.',
    timestamp: '2 days ago',
    unreadCount: 0,
    isOnline: false,
  },
];

export default function ChatScreen() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({
    '1': [
      {
        id: 'm1',
        text: 'Hello! We\'ve reviewed your application for the Front-end Developer position.',
        senderId: '101',
        receiverId: 'me',
        timestamp: '10:15 AM',
        isRead: true,
      },
      {
        id: 'm2',
        text: 'We would like to invite you for an interview tomorrow at 2pm.',
        senderId: '101',
        receiverId: 'me',
        timestamp: '10:30 AM',
        isRead: false,
      },
    ],
    '2': [
      {
        id: 'm3',
        text: 'Thank you for applying to our UX/UI Designer position.',
        senderId: '102',
        receiverId: 'me',
        timestamp: 'Yesterday, 3:45 PM',
        isRead: true,
      },
      {
        id: 'm4',
        text: 'Your application has been received. We\'ll review it soon.',
        senderId: '102',
        receiverId: 'me',
        timestamp: 'Yesterday, 3:47 PM',
        isRead: true,
      },
    ],
    '3': [
      {
        id: 'm5',
        text: 'Hi there! Is the position still open?',
        senderId: 'me',
        receiverId: '103',
        timestamp: '2 days ago, 11:20 AM',
        isRead: true,
      },
      {
        id: 'm6',
        text: 'Thank you for your interest in our position.',
        senderId: '103',
        receiverId: 'me',
        timestamp: '2 days ago, 2:15 PM',
        isRead: true,
      },
    ],
  });

  const sendMessage = () => {
    if (!messageText.trim() || !selectedChat) return;
    
    const newMessage: ChatMessage = {
      id: `m${Math.random().toString(36).substr(2, 9)}`,
      text: messageText,
      senderId: 'me',
      receiverId: mockChatThreads.find(t => t.id === selectedChat)?.participantId || '',
      timestamp: 'Just now',
      isRead: false,
    };
    
    setMessages(prev => ({
      ...prev,
      [selectedChat]: [...(prev[selectedChat] || []), newMessage],
    }));
    
    setMessageText('');
  };

  const filteredChats = mockChatThreads.filter(thread => 
    thread.participantName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentChat = selectedChat ? 
    mockChatThreads.find(thread => thread.id === selectedChat) : 
    null;

  const currentMessages = selectedChat ? messages[selectedChat] || [] : [];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{i18n.t('chat.title')}</Text>
      </View>
      
      {!selectedChat ? (
        // Chat list view
        <>
          <View style={styles.searchContainer}>
            <Search size={20} color={Colors.neutral[400]} style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder={i18n.t('common.search')}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor={Colors.neutral[400]}
            />
          </View>
          
          <FlatList
            data={filteredChats}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity 
                style={styles.chatItem}
                onPress={() => setSelectedChat(item.id)}
                activeOpacity={0.7}
              >
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>
                    {item.participantName.charAt(0)}
                  </Text>
                  {item.isOnline && <View style={styles.onlineIndicator} />}
                </View>
                
                <View style={styles.chatContent}>
                  <View style={styles.chatHeader}>
                    <Text style={styles.chatName}>{item.participantName}</Text>
                    <Text style={styles.chatTime}>{item.timestamp}</Text>
                  </View>
                  
                  <View style={styles.chatPreview}>
                    <Text 
                      style={[
                        styles.chatMessage,
                        item.unreadCount > 0 && styles.unreadMessage
                      ]}
                      numberOfLines={1}
                    >
                      {item.lastMessage}
                    </Text>
                    
                    {item.unreadCount > 0 && (
                      <View style={styles.unreadBadge}>
                        <Text style={styles.unreadBadgeText}>{item.unreadCount}</Text>
                      </View>
                    )}
                  </View>
                </View>
              </TouchableOpacity>
            )}
            contentContainerStyle={styles.chatList}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>{i18n.t('chat.noMessages')}</Text>
              </View>
            }
          />
        </>
      ) : (
        // Chat detail view
        <>
          <View style={styles.chatHeader}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => setSelectedChat(null)}
            >
              <Text style={styles.backButtonText}>{i18n.t('common.back')}</Text>
            </TouchableOpacity>
            
            <View style={styles.chatUserInfo}>
              <Text style={styles.chatUserName}>{currentChat?.participantName}</Text>
              {currentChat?.isOnline && <Text style={styles.chatUserStatus}>Online</Text>}
            </View>
          </View>
          
          <FlatList
            data={currentMessages}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View 
                style={[
                  styles.messageContainer,
                  item.senderId === 'me' ? styles.sentMessage : styles.receivedMessage
                ]}
              >
                <View 
                  style={[
                    styles.messageBubble,
                    item.senderId === 'me' ? styles.sentBubble : styles.receivedBubble
                  ]}
                >
                  <Text style={styles.messageText}>{item.text}</Text>
                  <Text style={styles.messageTime}>{item.timestamp}</Text>
                </View>
              </View>
            )}
            contentContainerStyle={styles.messagesList}
            showsVerticalScrollIndicator={false}
            inverted={false}
          />
          
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={i18n.t('chat.enterMessage')}
              value={messageText}
              onChangeText={setMessageText}
              multiline
            />
            <TouchableOpacity 
              style={[
                styles.sendButton,
                !messageText.trim() && styles.disabledSendButton
              ]}
              onPress={sendMessage}
              disabled={!messageText.trim()}
            >
              <Send size={20} color={messageText.trim() ? Colors.white : Colors.neutral[400]} />
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  header: {
    padding: Theme.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  title: {
    fontSize: Theme.typography.fontSize.xxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    margin: Theme.spacing.md,
    borderRadius: Theme.borderRadius.md,
    paddingHorizontal: Theme.spacing.md,
  },
  searchIcon: {
    marginRight: Theme.spacing.sm,
  },
  searchInput: {
    flex: 1,
    height: 44,
    fontFamily: Theme.typography.fontFamily.regular,
    fontSize: Theme.typography.fontSize.md,
    color: Colors.neutral[900],
  },
  chatList: {
    padding: Theme.spacing.md,
  },
  chatItem: {
    flexDirection: 'row',
    padding: Theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: Colors.primary[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Theme.spacing.md,
    position: 'relative',
  },
  avatarText: {
    fontSize: Theme.typography.fontSize.xl,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.primary[700],
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.success[500],
    borderWidth: 2,
    borderColor: Colors.white,
  },
  chatContent: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  chatName: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[900],
  },
  chatTime: {
    fontSize: Theme.typography.fontSize.xs,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[500],
  },
  chatPreview: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  chatMessage: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[600],
    flex: 1,
  },
  unreadMessage: {
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[900],
  },
  unreadBadge: {
    backgroundColor: Colors.primary[500],
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 8,
    marginLeft: Theme.spacing.sm,
  },
  unreadBadgeText: {
    color: Colors.white,
    fontSize: Theme.typography.fontSize.xs,
    fontFamily: Theme.typography.fontFamily.bold,
  },
  emptyContainer: {
    padding: Theme.spacing.xxl,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.md,
    color: Colors.neutral[500],
  },
  // Chat detail styles
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  backButton: {
    paddingRight: Theme.spacing.md,
  },
  backButtonText: {
    color: Colors.primary[500],
    fontFamily: Theme.typography.fontFamily.medium,
  },
  chatUserInfo: {
    flex: 1,
  },
  chatUserName: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[900],
  },
  chatUserStatus: {
    fontSize: Theme.typography.fontSize.xs,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.success[500],
  },
  messagesList: {
    flexGrow: 1,
    padding: Theme.spacing.md,
  },
  messageContainer: {
    marginBottom: Theme.spacing.md,
    maxWidth: '80%',
  },
  sentMessage: {
    alignSelf: 'flex-end',
  },
  receivedMessage: {
    alignSelf: 'flex-start',
  },
  messageBubble: {
    borderRadius: Theme.borderRadius.md,
    padding: Theme.spacing.md,
  },
  sentBubble: {
    backgroundColor: Colors.primary[500],
  },
  receivedBubble: {
    backgroundColor: Colors.neutral[100],
  },
  messageText: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.white,
    marginBottom: 4,
  },
  messageTime: {
    fontSize: Theme.typography.fontSize.xs,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.white,
    opacity: 0.7,
    alignSelf: 'flex-end',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: Theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[200],
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    backgroundColor: Colors.neutral[100],
    borderRadius: Theme.borderRadius.md,
    padding: Theme.spacing.sm,
    maxHeight: 100,
    fontFamily: Theme.typography.fontFamily.regular,
    fontSize: Theme.typography.fontSize.md,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: Theme.spacing.sm,
  },
  disabledSendButton: {
    backgroundColor: Colors.neutral[200],
  },
});