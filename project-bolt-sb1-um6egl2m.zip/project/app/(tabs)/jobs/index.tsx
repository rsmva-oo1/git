import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Filter, Bell } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import JobCard from '@/components/job/JobCard';
import FilterModal from '@/components/Layout/FilterModal';
import i18n from '@/utils/i18n';
import { Job } from '@/types/job';

// Mock data
const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Front-end Developer',
    companyName: 'TechCorp LLC',
    location: 'Tashkent, Uzbekistan',
    type: 'Full-time',
    schedule: 'Flexible',
    salary: '$1500-$2000',
    description: 'We are seeking a skilled Front-end Developer to join our team. The successful candidate will be responsible for implementing visual elements and their behaviors with user interactions.',
    requirements: [
      'Proficient in HTML, CSS, and JavaScript',
      'Experience with React.js',
      'Good understanding of responsive design',
      'Knowledge of UI/UX principles'
    ],
    responsibilities: [
      'Develop new user-facing features',
      'Build reusable code and libraries for future use',
      'Optimize applications for maximum speed',
      'Collaborate with backend developers and designers'
    ],
    tags: ['React', 'JavaScript', 'HTML', 'CSS'],
    postedTime: '2 days ago',
    postedDate: new Date('2025-06-15'),
    isFeatured: true
  },
  {
    id: '2',
    title: 'UX/UI Designer',
    companyName: 'Creative Solutions',
    location: 'Remote',
    type: 'Contract',
    schedule: '9-5',
    salary: '$2000-$3000',
    description: 'Creative Solutions is looking for a talented UX/UI Designer to create amazing user experiences for our clients.',
    requirements: [
      'Strong portfolio of design projects',
      'Proficiency in design software like Figma',
      'Experience creating wireframes and prototypes',
      'Understanding of user research methodologies'
    ],
    responsibilities: [
      'Create user flows, wireframes, and prototypes',
      'Conduct user research and testing',
      'Work closely with developers to implement designs',
      'Iterate on designs based on feedback'
    ],
    tags: ['Figma', 'UI Design', 'UX Research', 'Prototyping'],
    postedTime: '3 days ago',
    postedDate: new Date('2025-06-14'),
    isRemote: true
  },
  {
    id: '3',
    title: 'Digital Marketing Specialist',
    companyName: 'Media Group',
    location: 'Samarkand, Uzbekistan',
    type: 'Full-time',
    schedule: 'Flexible',
    description: 'We are seeking a Digital Marketing Specialist to develop and implement marketing strategies across digital channels.',
    requirements: [
      'Proven experience in digital marketing',
      'Knowledge of SEO/SEM, Google Analytics',
      'Experience with social media marketing',
      'Strong analytical skills'
    ],
    responsibilities: [
      'Develop and manage digital marketing campaigns',
      'Optimize content for SEO',
      'Analyze website traffic and user metrics',
      'Collaborate with content team'
    ],
    tags: ['Digital Marketing', 'SEO', 'Social Media', 'Analytics'],
    postedTime: '5 days ago',
    postedDate: new Date('2025-06-12')
  }
];

// Filter options
const filterSections = [
  {
    id: 'jobType',
    title: 'Job Type',
    options: [
      { id: 'fullTime', label: 'Full-time' },
      { id: 'partTime', label: 'Part-time' },
      { id: 'contract', label: 'Contract' },
      { id: 'freelance', label: 'Freelance' },
      { id: 'internship', label: 'Internship' }
    ],
    multiSelect: true
  },
  {
    id: 'location',
    title: 'Location',
    options: [
      { id: 'remote', label: 'Remote' },
      { id: 'tashkent', label: 'Tashkent' },
      { id: 'samarkand', label: 'Samarkand' },
      { id: 'bukhara', label: 'Bukhara' },
      { id: 'namangan', label: 'Namangan' }
    ]
  },
  {
    id: 'experience',
    title: 'Experience Level',
    options: [
      { id: 'entry', label: 'Entry Level' },
      { id: 'mid', label: 'Mid Level' },
      { id: 'senior', label: 'Senior Level' },
      { id: 'executive', label: 'Executive' }
    ],
    multiSelect: true
  },
  {
    id: 'postedDate',
    title: 'Posted Date',
    options: [
      { id: 'anytime', label: 'Anytime' },
      { id: 'today', label: 'Today' },
      { id: 'week', label: 'Past Week' },
      { id: 'month', label: 'Past Month' }
    ]
  }
];

export default function JobsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState<Record<string, string | string[]>>({});
  const [savedJobs, setSavedJobs] = useState<string[]>([]);

  // Filter jobs based on search query and filters
  const filteredJobs = mockJobs.filter(job => {
    // Search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !job.title.toLowerCase().includes(query) &&
        !job.companyName.toLowerCase().includes(query) &&
        !job.tags.some(tag => tag.toLowerCase().includes(query))
      ) {
        return false;
      }
    }
    
    // Apply other filters here
    return true;
  });

  const toggleSaveJob = (jobId: string) => {
    setSavedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId) 
        : [...prev, jobId]
    );
  };

  const handleFilterApply = (filters: Record<string, string | string[]>) => {
    setAppliedFilters(filters);
    // In a real app, you would update the filtered jobs based on these filters
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.title}>{i18n.t('jobs.title')}</Text>
          <TouchableOpacity style={styles.notificationButton}>
            <Bell size={24} color={Colors.neutral[700]} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.searchContainer}>
          <View style={styles.searchInputContainer}>
            <Search size={20} color={Colors.neutral[400]} style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder={i18n.t('common.search')}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor={Colors.neutral[400]}
            />
          </View>
          
          <TouchableOpacity 
            style={styles.filterButton}
            onPress={() => setFilterModalVisible(true)}
          >
            <Filter size={20} color={Colors.neutral[700]} />
          </TouchableOpacity>
        </View>
      </View>
      
      <FlatList
        data={filteredJobs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <JobCard 
            job={item}
            isSaved={savedJobs.includes(item.id)}
            onSave={() => toggleSaveJob(item.id)}
          />
        )}
        contentContainerStyle={styles.jobsList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No jobs found</Text>
          </View>
        }
      />
      
      <FilterModal
        visible={filterModalVisible}
        onClose={() => setFilterModalVisible(false)}
        onApply={handleFilterApply}
        filters={filterSections}
        initialValues={appliedFilters}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Theme.spacing.lg,
    ...Theme.shadow.sm,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.md,
  },
  title: {
    fontSize: Theme.typography.fontSize.xxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: Theme.borderRadius.full,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    borderRadius: Theme.borderRadius.md,
    paddingHorizontal: Theme.spacing.md,
    height: 44,
  },
  searchIcon: {
    marginRight: Theme.spacing.sm,
  },
  searchInput: {
    flex: 1,
    height: 44,
    fontFamily: Theme.typography.fontFamily.regular,
    fontSize: Theme.typography.fontSize.md,
    color: Colors.neutral[900],
  },
  filterButton: {
    width: 44,
    height: 44,
    borderRadius: Theme.borderRadius.md,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: Theme.spacing.sm,
  },
  jobsList: {
    padding: Theme.spacing.md,
  },
  emptyContainer: {
    padding: Theme.spacing.xxl,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontFamily: Theme.typography.fontFamily.medium,
    fontSize: Theme.typography.fontSize.md,
    color: Colors.neutral[500],
  },
});