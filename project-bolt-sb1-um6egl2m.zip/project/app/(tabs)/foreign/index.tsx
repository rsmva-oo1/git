import React, { useState } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Upload, CheckCircle, AlertCircle } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import i18n from '@/utils/i18n';

// Mock Countries Data
const countries = [
  { id: '1', name: 'South Korea', flag: 'https://images.pexels.com/photos/1850021/pexels-photo-1850021.jpeg', jobCount: 120 },
  { id: '2', name: 'United Arab Emirates', flag: 'https://images.pexels.com/photos/3428289/pexels-photo-3428289.jpeg', jobCount: 85 },
  { id: '3', name: 'Poland', flag: 'https://images.pexels.com/photos/14910659/pexels-photo-14910659.jpeg', jobCount: 67 },
  { id: '4', name: 'United States', flag: 'https://images.pexels.com/photos/774356/pexels-photo-774356.jpeg', jobCount: 120 },
  { id: '5', name: 'Germany', flag: 'https://images.pexels.com/photos/109629/pexels-photo-109629.jpeg', jobCount: 43 },
  { id: '6', name: 'Czech Republic', flag: 'https://images.pexels.com/photos/1658967/pexels-photo-1658967.jpeg', jobCount: 38 },
];

type VerificationStatus = 'pending' | 'verified' | 'rejected' | 'notSubmitted';

interface Document {
  type: 'passport' | 'languageCertificate';
  status: VerificationStatus;
  message?: string;
}

export default function ForeignJobsScreen() {
  const [documents, setDocuments] = useState<Record<string, Document>>({
    passport: {
      type: 'passport',
      status: 'notSubmitted',
    },
    languageCertificate: {
      type: 'languageCertificate',
      status: 'notSubmitted',
    }
  });

  const handleUploadDocument = (type: 'passport' | 'languageCertificate') => {
    // In a real app, this would open document picker
    console.log(`Upload ${type}`);
    
    // Simulate document upload
    setDocuments(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        status: 'pending',
      }
    }));

    // Simulate verification process
    setTimeout(() => {
      setDocuments(prev => ({
        ...prev,
        [type]: {
          ...prev[type],
          status: 'verified',
        }
      }));
    }, 2000);
  };

  const getStatusIcon = (status: VerificationStatus) => {
    switch (status) {
      case 'verified':
        return <CheckCircle size={20} color={Colors.success[500]} />;
      case 'rejected':
        return <AlertCircle size={20} color={Colors.error[500]} />;
      case 'pending':
        return <Upload size={20} color={Colors.warning[500]} />;
      default:
        return null;
    }
  };

  const isFullyVerified = documents.passport.status === 'verified' && 
                          documents.languageCertificate.status === 'verified';

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{i18n.t('foreign.title')}</Text>
      </View>
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{i18n.t('foreign.verification')}</Text>
          <Text style={styles.sectionDescription}>
            To apply for international jobs, please upload the following documents for verification:
          </Text>
          
          <Card variant="outlined">
            <View style={styles.documentItem}>
              <View style={styles.documentInfo}>
                <Text style={styles.documentTitle}>{i18n.t('foreign.passport')}</Text>
                <Text style={styles.documentDesc}>Upload your passport for identity verification</Text>
              </View>
              
              <View style={styles.documentActions}>
                {getStatusIcon(documents.passport.status)}
                
                <Button
                  title={
                    documents.passport.status === 'notSubmitted' 
                      ? i18n.t('foreign.uploadPassport')
                      : documents.passport.status === 'verified'
                      ? 'Verified'
                      : documents.passport.status === 'rejected'
                      ? 'Re-upload'
                      : 'Uploading...'
                  }
                  onPress={() => handleUploadDocument('passport')}
                  variant={documents.passport.status === 'verified' ? 'ghost' : 'primary'}
                  size="sm"
                  disabled={documents.passport.status === 'pending' || documents.passport.status === 'verified'}
                  style={styles.uploadButton}
                />
              </View>
            </View>
          </Card>
          
          <Card variant="outlined">
            <View style={styles.documentItem}>
              <View style={styles.documentInfo}>
                <Text style={styles.documentTitle}>{i18n.t('foreign.languageCert')}</Text>
                <Text style={styles.documentDesc}>Upload language proficiency certificates</Text>
              </View>
              
              <View style={styles.documentActions}>
                {getStatusIcon(documents.languageCertificate.status)}
                
                <Button
                  title={
                    documents.languageCertificate.status === 'notSubmitted' 
                      ? i18n.t('foreign.uploadCert')
                      : documents.languageCertificate.status === 'verified'
                      ? 'Verified'
                      : documents.languageCertificate.status === 'rejected'
                      ? 'Re-upload'
                      : 'Uploading...'
                  }
                  onPress={() => handleUploadDocument('languageCertificate')}
                  variant={documents.languageCertificate.status === 'verified' ? 'ghost' : 'primary'}
                  size="sm"
                  disabled={documents.languageCertificate.status === 'pending' || documents.languageCertificate.status === 'verified'}
                  style={styles.uploadButton}
                />
              </View>
            </View>
          </Card>
        </View>
        
        {isFullyVerified && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{i18n.t('foreign.countries')}</Text>
            <Text style={styles.sectionDescription}>
              Browse job opportunities in the following countries:
            </Text>
            
            <View style={styles.countriesGrid}>
              {countries.map(country => (
                <TouchableOpacity key={country.id} style={styles.countryCard}>
                  <Image 
                    source={{ uri: country.flag }} 
                    style={styles.countryFlag} 
                    resizeMode="cover"
                  />
                  <View style={styles.countryInfo}>
                    <Text style={styles.countryName}>{country.name}</Text>
                    <Text style={styles.jobCount}>{country.jobCount} jobs</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  header: {
    backgroundColor: Colors.white,
    padding: Theme.spacing.lg,
    ...Theme.shadow.sm,
  },
  title: {
    fontSize: Theme.typography.fontSize.xxl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Theme.spacing.md,
  },
  section: {
    marginBottom: Theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: Theme.typography.fontSize.xl,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.sm,
  },
  sectionDescription: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[700],
    marginBottom: Theme.spacing.md,
  },
  documentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  documentInfo: {
    flex: 1,
  },
  documentTitle: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[900],
    marginBottom: 4,
  },
  documentDesc: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[600],
  },
  documentActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  uploadButton: {
    marginLeft: Theme.spacing.sm,
  },
  countriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  countryCard: {
    width: '48%',
    backgroundColor: Colors.white,
    borderRadius: Theme.borderRadius.md,
    overflow: 'hidden',
    marginBottom: Theme.spacing.md,
    ...Theme.shadow.sm,
  },
  countryFlag: {
    width: '100%',
    height: 100,
  },
  countryInfo: {
    padding: Theme.spacing.sm,
  },
  countryName: {
    fontSize: Theme.typography.fontSize.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Colors.neutral[900],
  },
  jobCount: {
    fontSize: Theme.typography.fontSize.sm,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Colors.neutral[600],
  },
});