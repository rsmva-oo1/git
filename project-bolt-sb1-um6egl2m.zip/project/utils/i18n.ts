import * as Localization from 'expo-localization';
import { I18n } from 'i18n-js';
import { en, ru, uz } from '@/translations';

// Set the supported translations
const translations = {
  en,
  ru,
  uz,
};

// Create the i18n instance
const i18n = new I18n(translations);

// Set the locale from the device
i18n.locale = Localization.locale.split('-')[0];

// Fallback to 'en' if the locale isn't available
i18n.enableFallback = true;
i18n.defaultLocale = 'en';

// Helper function to change the language
export const changeLanguage = (locale: string) => {
  i18n.locale = locale;
};

export default i18n;